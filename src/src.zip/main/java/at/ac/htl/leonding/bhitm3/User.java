package at.ac.htl.leonding.bhitm3;

import java.util.List;

public class User extends Person {
    private int userId;

    private static int counter = 0;

    private List<Garden> garden;

    
}
