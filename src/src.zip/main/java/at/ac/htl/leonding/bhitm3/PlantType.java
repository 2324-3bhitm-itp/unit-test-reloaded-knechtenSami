package at.ac.htl.leonding.bhitm3;

public enum PlantType {
    FLOWER,
    TREE,
    SHRUB,
    GRASS,
    HERB,
    VEGETABLE,
    FRUIT,
    BERRY,
    CACTUS
}
